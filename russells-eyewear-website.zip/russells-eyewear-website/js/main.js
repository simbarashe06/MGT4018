const menuToggle = document.querySelector(".menu-toggle");
const mainNav = document.querySelector(".main-nav");

if (menuToggle && mainNav) {
  menuToggle.addEventListener("click", () => {
    const isOpen = mainNav.classList.toggle("is-open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
  });

  mainNav.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      mainNav.classList.remove("is-open");
      menuToggle.setAttribute("aria-expanded", "false");
    });
  });
}

const searchDialog = document.querySelector(".search-dialog");
const openSearch = document.querySelector("[data-open-search]");
if (searchDialog && openSearch) {
  openSearch.addEventListener("click", () => searchDialog.showModal());
}

const newsletter = document.querySelector(".newsletter-form");
if (newsletter) {
  newsletter.addEventListener("submit", event => {
    event.preventDefault();
    const email = newsletter.querySelector("input").value.trim();
    const message = document.querySelector(".form-message");
    if (email) {
      message.textContent = "Thank you — this demo does not store or submit your email.";
      newsletter.reset();
    }
  });
}
